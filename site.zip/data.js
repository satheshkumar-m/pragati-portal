/* Pragati Phonics — content (complete synthetic phonics, Letters and Sounds / Jolly Phonics order).
   Shared by the app and by tools/make-voice (via clips.json). */
(() => {
// id: [grapheme shown, IPA for the voice, fallback text, example word, picture, level, same-sound group]
const S = [
  // Level 1 — first letters (Phase 2)
  ['s','s','sː','sss','sun','☀️',1],['a','a','æ','a','apple','🍎',1],['t','t','tə','tuh','tiger','🐯',1],['p','p','pə','puh','pig','🐷',1],
  ['i','i','ɪ','ih','insect','🐛',1],['n','n','nː','nnn','nose','👃',1],['m','m','mː','mmm','moon','🌙',1],['d','d','də','duh','dog','🐶',1],
  ['g','g','ɡə','guh','goat','🐐',1],['o','o','ɒ','o','octopus','🐙',1],['c','c','kə','kuh','cat','🐱',1,'k'],['k','k','kə','kuh','kite','🪁',1,'k'],
  ['ck','ck','kə','kuh','duck','🦆',1,'k'],['e','e','ɛ','eh','egg','🥚',1],['u','u','ʌ','uh','umbrella','☂️',1],['r','r','ɹː','rrr','rabbit','🐰',1],
  ['h','h','hə','huh','hat','🎩',1],['b','b','bə','buh','ball','⚽',1],['f','f','fː','fff','fish','🐟',1,'f'],['ff','ff','fː','fff','muffin','🧁',1,'f'],
  ['l','l','lː','lll','lion','🦁',1,'l'],['ll','ll','lː','lll','bell','🔔',1,'l'],['ss','ss','sː','sss','dress','👗',1,'s'],
  // Level 2 — more letters (Phase 3)
  ['j','j','dʒə','juh','juice','🧃',2],['v','v','vː','vvv','van','🚐',2],['w','w','wə','wuh','web','🕸️',2,'w'],['x','x','ks','ks','fox','🦊',2],
  ['y','y','jə','yuh','yo-yo','🪀',2],['z','z','zː','zzz','zebra','🦓',2,'z'],['zz','zz','zː','zzz','buzz','🐝',2,'z'],['qu','qu','kwə','kwuh','queen','👑',2],
  // Level 3 — two letters, one sound (Phase 3 digraphs and trigraphs)
  ['ch','ch','tʃ','ch','chick','🐤',3],['sh','sh','ʃː','shh','ship','🚢',3],['th','th','θː','th','thumb','👍',3],['ng','ng','ŋ','ng','ring','💍',3],
  ['ai','ai','eɪ','ay','rain','🌧️',3,'ai'],['ee','ee','iː','ee','tree','🌳',3,'ee'],['igh','igh','aɪ','eye','light','💡',3,'igh'],['oa','oa','əʊ','oh','boat','⛵',3,'oa'],
  ['oo','oo','uː','oo','spoon','🥄',3,'oo'],['oo2','oo','ʊ','u','book','📖',3],['ar','ar','ɑː','ar','car','🚗',3],['or','or','ɔː','or','fork','🍴',3,'or'],
  ['ur','ur','ɜː','er','burger','🍔',3,'ur'],['ow','ow','aʊ','ow','cow','🐄',3,'ow'],['oi','oi','ɔɪ','oy','coin','🪙',3,'oi'],['ear','ear','ɪə','ear','ear','👂',3],
  ['air','air','eə','air','chair','🪑',3],['ure','ure','jʊə','your','cure','💊',3],['er','er','ə','er','letter','✉️',3],
  // Level 4 — other ways to spell sounds (Phase 5)
  ['ay','ay','eɪ','ay','tray','🍱',4,'ai'],['ou','ou','aʊ','ow','cloud','☁️',4,'ow'],['ie','ie','aɪ','eye','pie','🥧',4,'igh'],['ea','ea','iː','ee','leaf','🍃',4,'ee'],
  ['oy','oy','ɔɪ','oy','toy','🧸',4,'oi'],['ir','ir','ɜː','er','bird','🐦',4,'ur'],['ue','ue','juː','you','glue','🧴',4,'ue'],['aw','aw','ɔː','or','saw','🪚',4,'or'],
  ['wh','wh','wə','wuh','whale','🐳',4,'w'],['ph','ph','fː','fff','phone','📱',4,'f'],['ew','ew','juː','you','screw','🔩',4,'ue'],['oe','oe','əʊ','oh','toe','🦶',4,'oa'],
  ['au','au','ɔː','or','sauce','🥫',4,'or'],['ey','ey','iː','ee','key','🔑',4,'ee'],['a_e','a-e','eɪ','ay','cake','🎂',4,'ai'],['e_e','e-e','iː','ee','scene','🎬',4,'ee'],
  ['i_e','i-e','aɪ','eye','bike','🚲',4,'igh'],['o_e','o-e','əʊ','oh','home','🏠',4,'oa'],['u_e','u-e','juː','you','cube','🧊',4,'ue']
];
const sounds = {};
for (const [id, gr, ipa, say, word, pic, level, grp] of S) sounds[id] = { id, gr, ipa, say, word, pic, level, grp: grp || id };

// Blending words: tokens separated by spaces; "x=id" shows x but says sound id; "e=_" is a silent (magic) e.
const W = [
  ['p a t','pat','🤚'],['a n t','ant','🐜'],['p a n','pan','🍳'],['p i n','pin','📌'],['t a p','tap','🚰'],['n a p','nap','😴'],['t i n','tin','🥫'],['s i t','sit','🧘'],
  ['m a p','map','🗺️'],['d i g','dig','⛏️'],['d o g','dog','🐶'],['p i g','pig','🐷'],['m o p','mop','🧹'],['c a t','cat','🐱'],['k i d','kid','🧒'],['d u ck','duck','🦆'],
  ['s o ck','sock','🧦'],['h e n','hen','🐔'],['n e t','net','🥅'],['s u n','sun','☀️'],['c u p','cup','🥤'],['b u s','bus','🚌'],['r a t','rat','🐀'],['h a t','hat','🎩'],
  ['b a t','bat','🦇'],['b u g','bug','🐞'],['f a n','fan','🪭'],['l o g','log','🪵'],['l e g','leg','🦵'],['b e ll','bell','🔔'],['d o ll','doll','🪆'],
  ['j a m','jam','🍯'],['j e t','jet','✈️'],['v a n','van','🚐'],['w e b','web','🕸️'],['b o x','box','📦'],['s i x','six','6️⃣'],['y a k','yak','🐃'],['z i p','zip','🤐'],
  ['f o x','fox','🦊'],['j a zz','jazz','🎷'],['qu i z','quiz','❓'],
  ['sh i p','ship','🚢'],['f i sh','fish','🐟'],['sh o p','shop','🛍️'],['ch i p','chip','🍟'],['ch i n','chin','🧔'],['m o th','moth','🦋'],['r i ng','ring','💍'],['k i ng','king','🤴'],
  ['r ai n','rain','🌧️'],['t ai l','tail','🐒'],['f ee t','feet','🦶'],['b ee','bee','🐝'],['sh ee p','sheep','🐑'],['t ee th','teeth','🦷'],['n igh t','night','🌃'],['l igh t','light','💡'],
  ['b oa t','boat','⛵'],['g oa t','goat','🐐'],['m oo n','moon','🌙'],['z oo','zoo','🦁'],['b oo=oo2 k','book','📖'],['l oo=oo2 k','look','👀'],['c ar','car','🚗'],['s t ar','star','⭐'],
  ['sh ar k','shark','🦈'],['f ar m','farm','🚜'],['f or k','fork','🍴'],['c or n','corn','🌽'],['t or ch','torch','🔦'],['c ow','cow','🐄'],['ow l','owl','🦉'],['c oi n','coin','🪙'],
  ['oi l','oil','🛢️'],['ear','ear','👂'],['h air','hair','💇'],['ch air','chair','🪑'],
  ['d ay','day','🌞'],['c l ou d','cloud','☁️'],['p ie','pie','🥧'],['t ie','tie','👔'],['s ea','sea','🌊'],['l ea f','leaf','🍃'],['t oy','toy','🧸'],['b oy','boy','👦'],
  ['b ir d','bird','🐦'],['g ir l','girl','👧'],['b l ue','blue','🔵'],['s aw','saw','🪚'],['p aw','paw','🐾'],['wh a=a_e l e=_','whale','🐳'],['ph o=o_e n e=_','phone','📱'],
  ['c a=a_e k e=_','cake','🎂'],['b i=i_e k e=_','bike','🚲'],['k i=i_e t e=_','kite','🪁'],['h o=o_e m e=_','home','🏠'],['r o=o_e p e=_','rope','🪢'],['c u=u_e b e=_','cube','🧊']
];
const words = W.map(([spec, word, pic]) => ({ word, pic, tiles: spec.split(' ').map(t => { const [show, snd] = t.split('='); return { show, snd: snd === undefined ? show : (snd === '_' ? null : snd) } }) }));

window.PP_DATA = {
  // parent sound guide: [how to say it, common mistake], keyed by the sound group
  tips: {"s": ["Snake hiss \"sssss\", no voice.", "Saying \"ess\" (the letter name) or \"suh\"."], "a": ["Short \"a\" with the mouth open wide, as in apple.", "Saying \"ay\"."], "t": ["A tiny whispered tongue-tap behind the top teeth.", "Adding \"uh\": \"tuh\"."], "p": ["A whispered puff of air from the lips.", "Adding \"uh\": \"puh\"."], "i": ["Short \"i\", as in insect.", "Saying \"eye\"."], "n": ["Hum \"nnnn\" with the tongue behind the top teeth.", "Saying \"en\" or \"nuh\"."], "m": ["Hum \"mmmm\" with lips closed, like yummy food.", "Saying \"em\" or \"muh\"."], "d": ["A short \"d\", cut off quickly.", "A long \"duh\"."], "g": ["A short \"g\" from the throat, as in goat.", "Saying \"jee\"."], "o": ["Short round \"o\", jaw dropped, as in octopus.", "Saying \"oh\"."], "k": ["A whispered click from the back of the throat. c, k and ck all make this sound.", "Adding \"uh\": \"kuh\"."], "e": ["Short \"e\", as in egg.", "Saying \"ee\"."], "u": ["Short \"u\", like a surprised \"uh!\", as in umbrella.", "Saying \"you\"."], "r": ["Growly puppy \"rrrr\".", "Saying \"ar\" or \"ruh\"."], "h": ["A breathy whisper, like fogging a mirror.", "Saying \"aitch\" or \"huh\"."], "b": ["Lips pop, very short.", "A long \"buh\"."], "f": ["Top teeth on the bottom lip, blow \"ffff\", no voice. ff and ph make it too.", "Saying \"ef\" or \"fuh\"."], "l": ["Tongue up behind the teeth, \"llll\".", "Saying \"el\" or \"luh\"."], "j": ["A short \"j\", as in juice.", "Saying \"jay\"."], "v": ["Buzzy \"vvvv\", like f with voice.", "Saying \"vee\"."], "w": ["Round lips, a short \"w\". wh makes it too.", "Saying \"double-you\"."], "x": ["A quick \"ks\", as at the end of fox.", "Saying \"ex\"."], "y": ["A short \"y\", as in yo-yo.", "Saying \"why\"."], "z": ["Bee buzz \"zzzz\". zz makes it too.", "Saying \"zed\" or \"zee\"."], "qu": ["A quick \"kw\". q almost always comes with u.", "Saying \"kyoo\"."], "ch": ["A short whispered \"ch\", like a train.", "Saying \"chuh\"."], "sh": ["Quiet \"shhhh\", finger on lips.", "Adding \"uh\"."], "th": ["Tongue between the teeth and blow \"thhh\".", "Saying \"f\" or \"d\"."], "ng": ["The hum at the end of \"sing\" and \"ring\".", "Saying \"n\" and \"g\" separately."], "ai": ["\"ay\", as in rain. Also spelled ay (day) and a-e (cake).", "Saying \"a\" + \"i\" separately."], "ee": ["\"ee\", as in tree. Also spelled ea, ey and e-e.", "Saying it short."], "igh": ["\"eye\", as in light. Also spelled ie and i-e.", "Sounding out i-g-h."], "oa": ["\"oh\", as in boat. Also spelled oe and o-e.", "Saying \"o\" + \"a\" separately."], "oo": ["Long \"oo\", as in spoon and moon.", "Mixing it up with the short oo in book."], "oo2": ["Short \"oo\", as in book and look.", "Saying the long \"oo\" of moon."], "ar": ["\"ar\", as in car.", "Rolling a strong r."], "or": ["\"or\", as in fork. Also spelled aw (saw) and au (sauce).", "Saying \"o\" + \"r\" separately."], "ur": ["\"er\", as in burger. Also spelled ir (bird).", "Saying \"u\" + \"r\" separately."], "ow": ["\"ow\", as in cow, like \"ouch\". Also spelled ou (cloud).", "Saying \"oh\" (as in snow) — that one comes later."], "oi": ["\"oy\", as in coin. Also spelled oy (toy).", "Saying \"o\" + \"i\" separately."], "ear": ["\"ear\", as in ear and hear.", "Sounding out e-a-r."], "air": ["\"air\", as in chair.", "Sounding out a-i-r."], "ure": ["\"yoor\", as in cure and pure.", "Saying \"u-r-e\"."], "er": ["The soft \"uh\" at the end of letter and sister.", "Saying a strong \"er\" with r."], "ue": ["\"you\", as in glue. Also spelled ew (screw) and u-e (cube).", "Saying \"u\" + \"e\" separately."]},
  sounds, order: S.map(s => s[0]), freeCount: 6,
  levels: { 1: 'First letters', 2: 'More letters', 3: 'Two letters, one sound', 4: 'Other spellings' },
  traceLetters: 'satpinmdgockeurhbfljvwxyzq'.split(''),
  words,
  tricky: ['the','to','I','no','go','into','he','she','we','me','be','was','you','they','all','are','my','her','said','have','like','so','do','some','come','were','there','little','one','when','out','what','oh','their','people','Mr','Mrs','looked','called','asked','could'],
  freeTricky: 5,
  phrases: {
    p_hi: "Hello! Let's play with sounds!",
    p_which: 'Which one makes this sound?',
    p_yes1: 'Yes! Well done!', p_yes2: 'Great listening!', p_yes3: 'You got it!',
    p_try: 'Oops! Listen again.',
    p_blend: 'Tap each sound, then press blend!',
    p_trace: 'Trace the letter with your finger.',
    p_super: 'Super tracing!',
    p_ask: 'Ask a grown-up to unlock more sounds.',
    p_sticker: 'Wow! You won a new sticker!',
    p_tricky: 'Tricky words. We just have to remember them!',
    p_findword: 'Can you find this word?',
    p_magic: 'Magic e! It is quiet, but it changes the sound.'
  },
  avatars: ['🦁','🐼','🐰','🦊','🐯','🐨','🐸','🦄'],
  stickers: ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🐔','🐧','🐦','🦆','🦉','🐴','🦄','🐝','🦋','🐌','🐞','🐢','🐙','🐬','🐳','🦒','🐘','🦓','🦩','🦚','🦜','🐿️','🦔','🐊','🦖']
};
})();
