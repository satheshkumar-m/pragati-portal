/* Pragati Phonics — public settings (safe to show). Secret keys live only in config.php on the server. */
window.PP_CONFIG = {
  appName: 'Pragati Phonics',
  tagline: 'Complete phonics for ages 3 to 7 — sounds, blending, tracing and tricky words',
  priceLabel: '₹999',            // must match PRICE_PAISE in config.php
  priceNote: 'One-time payment · 3 years access · up to 2 children',
  maxChildren: 2,
  accessYears: 3,
  api: 'api.php',
  businessName: 'Pragati Learning',
  contactEmail: '',              // e.g. support@yourdomain.in — required by Razorpay before going live
  contactPhone: '',
  city: 'Bengaluru, Karnataka',
  version: '1.2 (28 Nov 2026)'
};
