/* Pragati Phonics — app */
{
const CFG = Object.assign({ appName: 'Pragati Phonics', priceLabel: '₹999', priceNote: '', api: 'api.php', maxChildren: 2, accessYears: 3 }, window.PP_CONFIG || {});
const MAXK = CFG.maxChildren;
const fmtDate = ms => new Date(ms).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
const DATA = window.PP_DATA;
const SD = DATA.sounds, ORDER = DATA.order, FREE = ORDER.slice(0, DATA.freeCount);
const LV = id => SD[id].level;
const KC = ['--k1', '--k2', '--k3', '--k4', '--k5', '--k6'];
const col = id => { let h = 0; for (const ch of String(id)) h += ch.charCodeAt(0); return `var(${KC[h % 6]})` };
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d } catch (e) { return d } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch (e) {} }
};
const today = (d = new Date()) => d.toISOString().slice(0, 10);
const app = document.getElementById('app');
const gid = id => 'g_' + id;
const wid = w => 'w_' + String(w).toLowerCase().replace(/[^a-z]/g, '');
const WORDTEXT = {};
for (const s of Object.values(SD)) WORDTEXT[wid(s.word)] = s.word;
for (const w of DATA.words) WORDTEXT[wid(w.word)] = w.word;
for (const t of DATA.tricky) WORDTEXT[wid(t)] = t === 'Mr' ? 'Mister' : t === 'Mrs' ? 'Missus' : t;
const wordLevel = w => Math.max(1, ...w.tiles.filter(t => t.snd).map(t => LV(t.snd)));

/* ---------- state ---------- */
let D = store.get('pp_data', null) || { children: [], active: null, welcomed: false, settings: { caseMode: 'lower', rate: 0.85, myVoice: true } };
let LIC = store.get('pp_license', null);
let demoPro = false;
const save = () => store.set('pp_data', D);
const kid = () => D.children.find(c => c.id === D.active) || null;
const fixKid = c => { for (const k of ['seen', 'right', 'wrong', 'traced', 'blended', 'days', 'tricky']) c[k] = c[k] || {}; c.level = c.level || 1; c.stickers = c.stickers || 0; c.stars = c.stars || 0; return c };
D.children.forEach(fixKid);
const pro = () => !!(LIC && LIC.token && (!LIC.expires || LIC.expires > Date.now())) || demoPro;
const open = id => pro() || FREE.includes(id);
const openWord = w => w.tiles.every(t => !t.snd || open(t.snd));
const openTricky = i => pro() || i < DATA.freeTricky;
const levelOpen = l => pro() || l === 1;
const caseOf = g => D.settings.caseMode === 'upper' ? g.toUpperCase() : g;
const glyph = id => { const g = SD[id].gr; if (D.settings.caseMode === 'both' && g.length === 1) return `<span class="L">${g.toUpperCase()}<small>${g}</small></span>`; return `<span class="L">${esc(caseOf(g))}</span>` };
const sz = id => { const n = SD[id].gr.replace('-', '').length; return n >= 3 ? 'g3' : n === 2 ? 'g2' : '' };
const newKid = (name, age, avatar) => fixKid({ id: 'k' + Date.now().toString(36), name, age, avatar });
function logDay() { const c = kid(); if (!c) return; const t = today(); c.days[t] = (c.days[t] || 0) + 1; save() }

/* ---------- letters sit in the middle of their boxes, whatever font loads ---------- */
async function fitLetters() {
  try { await document.fonts.load('700 100px Andika') } catch (e) {}
  try {
    const g = document.createElement('canvas').getContext('2d'); g.font = '700 100px Andika, sans-serif';
    const h = g.measureText('h'), p = g.measureText('p');
    const fA = h.fontBoundingBoxAscent / 100, fD = h.fontBoundingBoxDescent / 100, hA = h.actualBoundingBoxAscent / 100, pD = p.actualBoundingBoxDescent / 100;
    if (!fA || !hA) return;
    const base = (1 - (fA + fD)) / 2 + fA, want = .5 + (hA - pD) / 2;
    document.documentElement.style.setProperty('--lift', (want - base).toFixed(3) + 'em');
  } catch (e) {}
}

/* ---------- audio ---------- */
function clipText(id) {
  if (id.startsWith('g_')) return SD[id.slice(2)]?.say || '';
  if (id.startsWith('w_')) return WORDTEXT[id] || id.slice(2);
  return DATA.phrases[id] || '';
}
const AUD = { manifest: {}, pack: null, mine: {}, el: new Audio(), token: 0, worked: false };
AUD.el.preload = 'auto';
async function loadManifest() {
  try { const r = await fetch('audio/manifest.json', { cache: 'no-cache' }); if (r.ok) { AUD.manifest = await r.json(); return } } catch (e) {}
  try { const r = await fetch('audio-pack.json'); if (r.ok) AUD.pack = await r.json() } catch (e) {}   // single-file pack (preview copies)
}
function clipUrl(id) {
  if (D.settings.myVoice && AUD.mine[id]) return AUD.mine[id];
  if (AUD.manifest[id]) return 'audio/' + AUD.manifest[id];
  if (AUD.pack && AUD.pack[id]) return AUD.pack[id];
  return null;
}
function stopAudio() { AUD.token++; try { AUD.el.pause() } catch (e) {} try { speechSynthesis.cancel() } catch (e) {} }
const sleep = ms => new Promise(r => setTimeout(r, ms));
// play clips in order; a number in the list is a pause in ms. Resolves true if it finished, false if something else started.
async function play(...ids) {
  stopAudio(); const tok = AUD.token;
  for (const id of ids) {
    if (tok !== AUD.token) return false;
    if (typeof id === 'number') await sleep(id); else await playOne(id);
  }
  return tok === AUD.token;
}
// Ask a question the kid-friendly way: new screen first, then the question, a little pause, then the sound.
// Answer buttons stay soft and untappable until the sound has been heard; the ear bounces while it talks.
async function ask(promptId, soundId, boxId) {
  const box = document.getElementById(boxId), ear = document.querySelector('.ear');
  box?.classList.add('wait'); ear?.classList.add('talk');
  try { await play(450, promptId, 350, soundId) }
  finally { box?.classList.remove('wait'); ear?.classList.remove('talk') }
}
async function earSay(soundId) {
  const ear = document.querySelector('.ear'); ear?.classList.add('talk');
  try { await play(soundId) } finally { ear?.classList.remove('talk') }
}
function playOne(id) {
  return new Promise(res => {
    let done = false; const fin = () => { if (!done) { done = true; res() } };
    const url = clipUrl(id);
    if (!url) return speak(id).then(fin);
    const a = AUD.el; a.onended = fin; a.onerror = () => speak(id).then(fin);
    a.src = url;
    const p = a.play(); if (p && p.catch) p.then(() => { AUD.worked = true }).catch(() => speak(id).then(fin));
    setTimeout(fin, 6000);
  });
}
function speak(id) {
  return new Promise(res => {
    const t = clipText(id); if (!t || !('speechSynthesis' in window)) { soundHint(); return res() }
    try {
      const u = new SpeechSynthesisUtterance(t); u.rate = D.settings.rate; u.pitch = 1.1; u.lang = 'en-GB';
      const v = speechSynthesis.getVoices().find(v => /en[-_](GB|IN|US)/i.test(v.lang)); if (v) u.voice = v;
      let ok = false; u.onstart = () => { ok = true; AUD.worked = true }; u.onend = res; u.onerror = () => { soundHint(); res() };
      speechSynthesis.speak(u); setTimeout(() => { if (!ok) soundHint(); res() }, 2500);
    } catch (e) { soundHint(); res() }
  });
}
let hinted = false;
function soundHint() { if (hinted || AUD.worked) return; hinted = true; toast('🔈 No sound? Turn the volume up and switch off silent mode.') }
const sayGrapheme = id => play(gid(id), wid(SD[id].word));

/* my-voice recordings (IndexedDB) */
const idb = {
  db: null,
  open() { return new Promise((res, rej) => { try { const r = indexedDB.open('pp_voice', 1); r.onupgradeneeded = () => r.result.createObjectStore('clips'); r.onsuccess = () => res(this.db = r.result); r.onerror = () => rej(r.error) } catch (e) { rej(e) } }) },
  tx(mode) { return this.db.transaction('clips', mode).objectStore('clips') },
  all() { return new Promise(res => { const out = {}; try { const c = this.tx('readonly').openCursor(); c.onsuccess = () => { const cur = c.result; if (cur) { out[cur.key] = cur.value; cur.continue() } else res(out) }; c.onerror = () => res(out) } catch (e) { res(out) } }) },
  put(k, v) { return new Promise(res => { try { const r = this.tx('readwrite').put(v, k); r.onsuccess = res; r.onerror = res } catch (e) { res() } }) },
  del(k) { return new Promise(res => { try { const r = this.tx('readwrite').delete(k); r.onsuccess = res; r.onerror = res } catch (e) { res() } }) }
};
let MINE_BLOBS = {};
async function loadMine() { try { await idb.open(); MINE_BLOBS = await idb.all(); for (const k in MINE_BLOBS) AUD.mine[k] = URL.createObjectURL(MINE_BLOBS[k]) } catch (e) {} }

/* ---------- server ---------- */
let API_OK = false;
async function api(a, body) {
  const r = await fetch(CFG.api + '?a=' + encodeURIComponent(a), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  let j; try { j = await r.json() } catch (e) { throw new Error('Server not reachable') }
  if (!r.ok || j.error) throw new Error(j.error || 'Server error');
  return j;
}
async function ping() { try { const j = await api('ping'); API_OK = !!j.ok; if (j.price_label) CFG.priceLabel = j.price_label } catch (e) { API_OK = false } }
async function checkLicense() {
  if (!LIC || !LIC.token || !API_OK) return;
  try { const j = await api('check', { token: LIC.token }); if (!j.valid) { LIC = null; store.set('pp_license', null); render() } else if (j.expires && j.expires !== LIC.expires) { LIC.expires = j.expires; store.set('pp_license', LIC) } } catch (e) {}
}

/* ---------- ui helpers ---------- */
function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 3200) }
function burst(chars = '⭐🌟✨🎉') {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const b = document.createElement('div'); b.className = 'burst'; const cs = [...chars];
  b.innerHTML = Array.from({ length: 22 }, (_, i) => `<span style="left:${Math.random() * 96}%;animation-delay:${Math.random() * .4}s">${cs[i % cs.length]}</span>`).join('');
  document.body.appendChild(b); setTimeout(() => b.remove(), 2200);
}
function addStar(n = 1) {
  const c = kid(); if (!c) return; c.stars += n;
  if (c.stars >= (c.stickers + 1) * 5 && c.stickers < DATA.stickers.length) {
    c.stickers++; save(); const s = DATA.stickers[c.stickers - 1];
    setTimeout(() => { burst(s + '⭐'); play('p_sticker'); showSticker(s) }, 1400);
  }
  save(); const el = document.getElementById('starPill'); if (el) el.textContent = '⭐ ' + c.stars;
}
function showSticker(s) { overlay(`<div class="sheet"><div style="font-size:110px;line-height:1">${s}</div><h2>New sticker!</h2><p class="muted">It is in your sticker book.</p><div class="row"><button class="btn" data-act="closeOv">Yay!</button></div></div>`) }
function overlay(html) { closeOv(); const o = document.createElement('div'); o.className = 'overlay'; o.id = 'ov'; o.innerHTML = html; document.body.appendChild(o); o.addEventListener('click', e => { if (e.target === o) closeOv() }); bindActs(o) }
function closeOv() { const o = document.getElementById('ov'); if (o) o.remove() }
const brandHtml = () => `<div class="brand"><div class="logo">प्र</div><div>${esc(CFG.appName)}<small>by Pragati · Learning Skills Lab</small></div></div>`;

/* ---------- router ---------- */
let view = 'home', vstate = {};
function go(v, st = {}) { stopAudio(); view = v; vstate = st; render(); window.scrollTo(0, 0) }
function render() {
  if (!D.welcomed) view = 'welcome';
  else if (!D.children.length && view !== 'parent') view = 'addKid';
  app.innerHTML = (VIEWS[view] || VIEWS.home)();
  bindActs(app);
  if (AFTER[view]) AFTER[view]();
}
const ACT = {}, VIEWS = {}, AFTER = {};
function bindActs(root) {
  root.querySelectorAll('[data-act]').forEach(el => {
    if (el._b) return; el._b = 1;
    el.addEventListener(el.tagName === 'FORM' ? 'submit' : 'click', e => { if (el.tagName === 'FORM') e.preventDefault(); const f = ACT[el.dataset.act]; if (f) f(el, e) });
  });
}
ACT.closeOv = closeOv;
ACT.go = el => go(el.dataset.v);
const kidTop = (title = '') => { const c = kid(); return `<div class="top"><button class="home" data-act="go" data-v="home" aria-label="Home">🏠</button><b class="baloo ttl">${title}</b><span class="pill" id="starPill">⭐ ${c ? c.stars : 0}</span></div>` };
const levelChips = () => { const c = kid(); return `<div class="lvls" role="tablist">${[1, 2, 3, 4].map(l => `<button role="tab" aria-selected="${c.level === l}" data-act="setLevel" data-l="${l}">${levelOpen(l) ? '' : '🔒 '}${l}<small>${DATA.levels[l]}</small></button>`).join('')}</div>` };
ACT.setLevel = el => { const l = +el.dataset.l; if (!levelOpen(l)) return locked(); const c = kid(); c.level = l; save(); vstate = {}; li = 0; wi = 0; render() };

/* ---------- welcome ---------- */
VIEWS.welcome = () => `
<div class="top">${brandHtml()}</div>
<section class="hero">
  <div>
    <h1>Help your little one <em>hear, read and write</em> every sound</h1>
    <p>${esc(CFG.tagline || '')}. All 44 sounds in the order schools teach them, in short joyful games, with a quiet progress report for you.</p>
    <div class="row" style="justify-content:flex-start"><button class="btn" data-act="start">Start free</button><button class="btn sec" data-act="seePrice">See price</button></div>
    <p class="small muted">No sign-up. The first 6 sounds (s a t p i n), their words and 5 tricky words are free forever.</p>
  </div>
  <div class="frieze" aria-hidden="true">${['s', 'a', '🐍', 'sh', '🐯', 'ee', 'i', '🍎', 'n'].map(x => /^[a-z]+$/.test(x) ? `<div style="--cc:${col(x)}" class="${x.length > 1 ? 'g2' : ''}"><span class="L">${x}</span></div>` : `<div class="pic">${x}</div>`).join('')}</div>
</section>
<div class="feats">
  <div class="feat"><i>🔤</i><b>All 44 sounds</b>Letters, then sh, ch, ee, igh, magic e and every other spelling — 69 in all.</div>
  <div class="feat"><i>👂</i><b>Listening game</b>Hear a sound, find it. It repeats the tricky ones more.</div>
  <div class="feat"><i>✍️</i><b>Finger tracing</b>Trace big letters to learn their shapes.</div>
  <div class="feat"><i>🧩</i><b>Blending</b>s-a-t → sat, sh-i-p → ship. ${DATA.words.length} picture words.</div>
  <div class="feat"><i>⭐</i><b>Tricky words</b>41 words like the, said and was that need remembering.</div>
  <div class="feat"><i>📊</i><b>Parent report</b>What is mastered, what is tricky, and what to do next.</div>
  <div class="feat"><i>🧑‍🏫</i><b>Parents learn too</b>A sound guide with how to say every sound, what to avoid, and a 10-minute plan for each day.</div>
</div>
<div class="price" id="price"><div><div class="amt">${esc(CFG.priceLabel)}</div><div>${esc(CFG.priceNote)}</div></div><button class="btn" data-act="start">Try it free first</button></div>
${footerHtml()}`;
ACT.start = () => { D.welcomed = true; save(); go(D.children.length ? 'home' : 'addKid') };
ACT.seePrice = () => document.getElementById('price').scrollIntoView({ behavior: 'smooth' });
const footerHtml = () => `<footer><span>© ${new Date().getFullYear()} ${esc(CFG.businessName || 'Pragati')}</span><a href="legal.html#privacy">Privacy</a><a href="legal.html#terms">Terms</a><a href="legal.html#refunds">Refunds</a><a href="legal.html#contact">Contact</a><span>v${esc(CFG.version || '')}</span></footer>`;

/* ---------- add child ---------- */
VIEWS.addKid = () => {
  const av = vstate.av || DATA.avatars[0];
  return `<div class="top">${brandHtml()}</div>
  <div class="card" style="max-width:520px;margin:10px auto">
    <h1 style="font-size:32px">Who is learning?</h1>
    <p class="muted">For grown-ups: add your child. You can add up to ${MAXK} children in the parent zone.</p>
    <form data-act="saveKid">
      <label class="field">Child's first name<input id="kName" maxlength="20" required autocomplete="off" value="${esc(vstate.name || '')}"></label>
      <label class="field">Age<select id="kAge"><option value="3">3 years</option><option value="4" selected>4 years</option><option value="5">5 years</option><option value="6">6 years</option><option value="7">7 years</option></select></label>
      <div class="field">Pick a buddy<div class="avatars">${DATA.avatars.map(a => `<button type="button" data-act="pickAv" data-a="${a}" aria-pressed="${a === av}">${a}</button>`).join('')}</div></div>
      <button class="btn block" type="submit">Let's go!</button>
    </form>
  </div>`;
};
ACT.pickAv = el => { vstate.av = el.dataset.a; vstate.name = document.getElementById('kName').value; render() };
ACT.saveKid = () => {
  const n = document.getElementById('kName').value.trim(); if (!n) return;
  if (D.children.length >= MAXK) { toast(`Up to ${MAXK} children per family.`); return }
  const c = newKid(n, +document.getElementById('kAge').value, vstate.av || DATA.avatars[0]);
  D.children.push(c); D.active = c.id; save(); go('home'); play('p_hi');
};

/* ---------- kid home ---------- */
VIEWS.home = () => {
  const c = kid() || D.children[0]; if (c && !kid()) { D.active = c.id; save() }
  return `<div class="top">${brandHtml()}<span class="pill" id="starPill">⭐ ${c.stars}</span></div>
  <div class="hello"><div class="av">${c.avatar}</div><div><h1>Hi ${esc(c.name)}!</h1><div class="muted">Level ${c.level}: ${DATA.levels[c.level]}</div></div></div>
  <div class="acts">
    <button class="act" style="--cc:var(--k1)" data-act="go" data-v="letters"><i>🔤</i><div><b>Sounds</b><br><span>Hear every sound</span></div></button>
    <button class="act" style="--cc:var(--k2)" data-act="go" data-v="listen"><i>👂</i><div><b>Listen</b><br><span>Find the sound</span></div></button>
    <button class="act" style="--cc:var(--k3)" data-act="go" data-v="trace"><i>✍️</i><div><b>Trace</b><br><span>Draw the letter</span></div></button>
    <button class="act" style="--cc:var(--k4)" data-act="go" data-v="blend"><i>🧩</i><div><b>Blend</b><br><span>Read little words</span></div></button>
    <button class="act wide" style="--cc:var(--k5)" data-act="go" data-v="tricky"><i>⭐</i><div><b>Tricky words</b><br><span>the, said, was…</span></div></button>
  </div>
  <div class="kidfoot">
    <button class="btn sec sm" data-act="go" data-v="stickers">🏅 My stickers (${c.stickers})</button>
    ${D.children.length > 1 ? `<button class="btn sec sm" data-act="switchKid">🔁 Switch child</button>` : ''}
    <button class="btn sec sm" data-act="gate" data-to="parent">🔒 Grown-ups</button>
  </div>`;
};
ACT.switchKid = () => overlay(`<div class="sheet"><h2>Who is playing?</h2><div class="list">${D.children.map(c => `<button class="li" data-act="useKid" data-id="${c.id}"><span class="ic">${c.avatar}</span><span class="grow baloo" style="font-size:22px;text-align:left">${esc(c.name)}</span>⭐ ${c.stars}</button>`).join('')}</div></div>`);
ACT.useKid = el => { D.active = el.dataset.id; save(); closeOv(); go('home') };

function locked() {
  play('p_ask');
  overlay(`<div class="sheet"><div style="font-size:80px">🔒</div><h2>More sounds are waiting!</h2><p class="muted">Ask a grown-up to unlock all 44 sounds, ${DATA.words.length} words and ${DATA.tricky.length} tricky words.</p><div class="row"><button class="btn" data-act="gate" data-to="plan">Grown-up: unlock</button><button class="btn sec" data-act="closeOv">Back</button></div></div>`);
}

/* ---------- sounds (letter cards) ---------- */
const levelIds = () => ORDER.filter(id => LV(id) === kid().level);
function wordHtml(id) {
  const s = SD[id], w = s.word; let idx = [];
  if (id.includes('_')) { const v = id[0]; const i = w.indexOf(v); idx = [i, w.length - 1] }
  else { const i = w.indexOf(s.gr); for (let k = 0; k < s.gr.length; k++) idx.push(i + k) }
  return [...w].map((ch, k) => idx.includes(k) ? `<b>${esc(ch)}</b>` : esc(ch)).join('');
}
let li = 0;
VIEWS.letters = () => `${kidTop('Sounds')}${levelChips()}<div class="big" id="lcard" data-act="hearLetter"></div>
  <div class="row ctrl"><button class="btn sec arrow" data-act="lstep" data-d="-1" aria-label="Previous">◀</button><button class="btn" data-act="hearSound">🔊 Sound</button><button class="btn" style="--cc:var(--k2)" data-act="hearWord">🗣️ Word</button><button class="btn sec arrow" data-act="lstep" data-d="1" aria-label="Next">▶</button></div>
  <div class="strip" id="strip"></div>`;
function drawLetter() {
  const ls = levelIds(); li = (li + ls.length) % ls.length; const id = ls[li], s = SD[id], c = kid();
  const card = document.getElementById('lcard'); card.style.setProperty('--cc', col(id));
  card.innerHTML = `<div class="glyph ${sz(id)}">${glyph(id)}</div><div><div class="pic">${s.pic}</div><div class="word">${wordHtml(id)}</div>${id.includes('_') ? '<div class="small muted center">magic e</div>' : ''}</div>`;
  document.getElementById('strip').innerHTML = ls.map((x, k) => `<button style="--cc:${col(x)}" class="${k === li ? 'cur' : ''} ${open(x) ? '' : 'lock'} ${sz(x)}" data-k="${k}" aria-label="Sound ${SD[x].gr}"><span class="L">${esc(caseOf(SD[x].gr))}</span>${!open(x) ? '<span class="tag">🔒</span>' : c.seen[x] ? '<span class="tag">✓</span>' : ''}</button>`).join('');
}
AFTER.letters = () => {
  drawLetter();
  document.getElementById('strip').onclick = e => { const b = e.target.closest('button'); if (!b) return; const x = levelIds()[+b.dataset.k]; if (!open(x)) return locked(); li = +b.dataset.k; drawLetter(); markSeen(); sayGrapheme(x) };
};
function markSeen() { const c = kid(), id = levelIds()[li]; if (!c.seen[id]) { c.seen[id] = 1; save() } logDay() }
ACT.lstep = el => { const ls = levelIds(); const n = (li + +el.dataset.d + ls.length) % ls.length; if (!open(ls[n])) return locked(); li = n; drawLetter(); markSeen(); sayGrapheme(ls[li]) };
ACT.hearLetter = () => { markSeen(); sayGrapheme(levelIds()[li]) };
ACT.hearSound = () => { markSeen(); play(gid(levelIds()[li])) };
ACT.hearWord = () => play(wid(SD[levelIds()[li]].word));

/* ---------- listen game ---------- */
VIEWS.listen = () => `${kidTop('Listen')}${levelChips()}<div class="q"><h2>Which one makes this sound?</h2>
  <button class="ear" data-act="replay" aria-label="Play the sound again">👂</button>
  <div class="choices" id="choices"></div><div class="msg" id="lmsg"></div>
  <button class="btn hide" style="--cc:var(--k3)" id="nextQ" data-act="nextQ">Next ▶</button>
  <div class="dots" id="dots"></div></div>`;
let G = { cur: null, tries: 0, done: false, round: 0 };
function listenPool() {
  const lvl = kid().level;
  let p = ORDER.filter(id => open(id) && LV(id) === lvl);
  if (p.length < 4) p = ORDER.filter(id => open(id) && LV(id) <= lvl);
  return p;
}
function newQ(first) {
  const pool0 = listenPool(), c = kid();
  const pool = pool0.flatMap(x => Array(1 + Math.min(3, c.wrong[x] || 0)).fill(x));
  let t, guard = 0; do { t = pool[Math.floor(Math.random() * pool.length)] } while (t === G.cur && ++guard < 20);
  G.cur = t; G.tries = 0; G.done = false;
  const opts = [t], grps = new Set([SD[t].grp]); guard = 0;
  while (opts.length < 3 && guard++ < 200) { const x = pool0[Math.floor(Math.random() * pool0.length)]; if (!grps.has(SD[x].grp)) { opts.push(x); grps.add(SD[x].grp) } }
  opts.sort(() => Math.random() - .5);
  document.getElementById('choices').innerHTML = opts.map(x => `<button data-c="${x}" style="--cc:${col(x)}" class="${sz(x)}" aria-label="${SD[x].gr}"><span class="L">${esc(caseOf(SD[x].gr))}</span></button>`).join('');
  document.getElementById('lmsg').textContent = ''; document.getElementById('nextQ').classList.add('hide');
  document.getElementById('dots').innerHTML = Array.from({ length: 5 }, (_, i) => `<i class="${i < G.round % 5 ? 'on' : ''}"></i>`).join('');
  ask('p_which', gid(t), 'choices');
}
AFTER.listen = () => {
  newQ(true);
  document.getElementById('choices').onclick = e => {
    const b = e.target.closest('button'); if (!b || G.done || b.classList.contains('no')) return;
    const x = b.dataset.c, c = kid();
    if (x === G.cur) {
      G.done = true; b.classList.add('ok'); logDay();
      if (G.tries === 0) { c.right[x] = (c.right[x] || 0) + 1; addStar() } else save();
      G.round++;
      document.getElementById('lmsg').textContent = G.tries === 0 ? 'Yes! ⭐' : 'You got it! 🎉';
      if (G.round % 5 === 0) burst();
      document.getElementById('nextQ').classList.remove('hide');
      play(['p_yes1', 'p_yes2', 'p_yes3'][Math.floor(Math.random() * 3)], wid(SD[x].word));
    } else {
      G.tries++; b.classList.add('no'); if (G.tries === 1) { c.wrong[G.cur] = (c.wrong[G.cur] || 0) + 1; save() }
      document.getElementById('lmsg').textContent = 'Nearly! Listen again 👂'; ask('p_try', gid(G.cur), 'choices');
    }
  };
};
ACT.replay = () => G.cur && earSay(gid(G.cur));
ACT.nextQ = () => newQ(false);

/* ---------- blend ---------- */
function wordList() {
  const lvl = kid().level, all = DATA.words.filter(openWord);
  const at = all.filter(w => wordLevel(w) === lvl);
  return at.length ? at : all.filter(w => wordLevel(w) <= lvl);
}
let wi = 0, tapped = new Set(), blendDone = new Set();
VIEWS.blend = () => `${kidTop('Blend')}${levelChips()}<div class="q"><h2>Tap each sound, then blend!</h2>
  <div class="tiles" id="tiles"></div><div class="pic hide" id="bpic" style="font-size:96px"></div><div class="msg" id="bmsg"></div>
  <div class="row"><button class="btn" style="--cc:var(--k4)" data-act="doBlend">✨ Blend it</button><button class="btn" style="--cc:var(--k3)" data-act="nextW">Next word ▶</button></div>
  ${pro() ? '' : `<p class="small muted">${DATA.words.filter(openWord).length} free words · <button class="small linkish" data-act="gate" data-to="plan">unlock all ${DATA.words.length}</button></p>`}</div>`;
function curWord() { const ws = wordList(); return ws[((wi % ws.length) + ws.length) % ws.length] }
function drawWord() {
  const w = curWord(); tapped = new Set(); let splitCol = null;
  document.getElementById('tiles').innerHTML = w.tiles.map((t, k) => {
    let cc = t.snd ? col(t.snd) : splitCol || '#9ca3af'; if (t.snd && t.snd.endsWith('_e')) splitCol = cc;
    return `<button data-k="${k}" style="--cc:${cc}" class="${t.show.length > 1 ? 'g2' : ''} ${t.snd ? '' : 'silent'} ${t.snd && t.snd.endsWith('_e') ? 'split' : ''}" aria-label="${esc(t.show)}"><span class="L">${esc(caseOf(t.show))}</span></button>`;
  }).join('');
  const bp = document.getElementById('bpic'); bp.textContent = w.pic; bp.classList.add('hide'); document.getElementById('bmsg').textContent = '';
}
AFTER.blend = () => {
  drawWord(); play('p_blend');
  document.getElementById('tiles').onclick = e => {
    const b = e.target.closest('button'); if (!b) return; const t = curWord().tiles[+b.dataset.k];
    b.classList.add('lit'); setTimeout(() => b.classList.remove('lit'), 400); tapped.add(b.dataset.k);
    play(t.snd ? gid(t.snd) : 'p_magic');
  };
};
ACT.doBlend = () => {
  const w = curWord(), tiles = [...document.getElementById('tiles').children], c = kid();
  const sounding = w.tiles.map((t, k) => [t, k]).filter(([t]) => t.snd);
  sounding.forEach(([, k], n) => setTimeout(() => { const t = tiles[k]; if (!t) return; t.classList.add('lit'); setTimeout(() => t.classList.remove('lit'), 500) }, n * 650));
  play(...sounding.map(([t]) => gid(t.snd)), wid(w.word));
  setTimeout(() => { document.getElementById('bpic')?.classList.remove('hide'); const m = document.getElementById('bmsg'); if (m) m.textContent = w.word + '! 🎉' }, sounding.length * 650 + 300);
  if (tapped.size >= sounding.length && !blendDone.has(w.word)) { blendDone.add(w.word); c.blended[w.word] = (c.blended[w.word] || 0) + 1; addStar(); logDay() }
};
ACT.nextW = () => { wi++; drawWord() };

/* ---------- trace ---------- */
let ti = 0, TR = null;
const traceList = () => DATA.traceLetters;
VIEWS.trace = () => `${kidTop('Trace')}<div class="q">
  <div class="board" id="board"><canvas id="cv"></canvas></div><div class="meter"><i id="meter"></i></div><div class="msg" id="tmsg"></div>
  <div class="row ctrl"><button class="btn sec arrow" data-act="tstep" data-d="-1" aria-label="Previous">◀</button><button class="btn sec" data-act="tclear">↺ Again</button><button class="btn" data-act="tsound">🔊</button><button class="btn sec arrow" data-act="tstep" data-d="1" aria-label="Next">▶</button></div></div>`;
async function setupTrace() {
  const ls = traceList(); ti = (ti + ls.length) % ls.length; const ch = ls[ti];
  const board = document.getElementById('board'), cv = document.getElementById('cv'); if (!board) return;
  try { await document.fonts.load('700 300px Andika') } catch (e) {}
  const S = board.clientWidth, dpr = Math.min(2, window.devicePixelRatio || 1);
  cv.width = S * dpr; cv.height = S * dpr; const g = cv.getContext('2d'); g.scale(dpr, dpr);
  const gl = caseOf(ch);
  g.clearRect(0, 0, S, S); g.font = `700 ${S * .72}px Andika, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  const m = g.measureText(gl); const asc = m.actualBoundingBoxAscent || S * .5, des = m.actualBoundingBoxDescent || 0;
  const y = S / 2 + (asc - des) / 2;
  g.fillStyle = 'rgba(232,93,4,.13)'; g.fillText(gl, S / 2, y);
  g.setLineDash([6, 10]); g.lineWidth = 3; g.strokeStyle = 'rgba(232,93,4,.45)'; g.strokeText(gl, S / 2, y); g.setLineDash([]);
  const off = document.createElement('canvas'); off.width = S; off.height = S; const o = off.getContext('2d');
  o.font = g.font; o.textAlign = 'center'; o.fillStyle = '#000'; o.fillText(gl, S / 2, y);
  const px = o.getImageData(0, 0, S, S).data, step = Math.max(6, Math.round(S / 40)), pts = [];
  for (let yy = 0; yy < S; yy += step) for (let xx = 0; xx < S; xx += step) if (px[(yy * S + xx) * 4 + 3] > 128) pts.push([xx, yy, 0]);
  TR = { ch, pts, hit: 0, inn: 0, out: 0, done: false, last: null };
  document.getElementById('meter').style.width = '0%'; document.getElementById('tmsg').textContent = '';
  const pos = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * S / r.width, (e.clientY - r.top) * S / r.height] };
  const R = S * .075;
  const near = (x, y) => TR.pts.some(p => (p[0] - x) ** 2 + (p[1] - y) ** 2 < (R * 1.6) ** 2);
  const mark = (x, y) => {
    if (near(x, y)) TR.inn++; else TR.out++;
    if (!TR.done && TR.out > 25 && TR.out > TR.inn * .6) { document.getElementById('tmsg').textContent = 'Stay on the letter 🙂 Try again!'; play('p_trace'); setTimeout(setupTrace, 900); TR.done = true; return }
    for (const p of TR.pts) if (!p[2] && (p[0] - x) ** 2 + (p[1] - y) ** 2 < R * R) { p[2] = 1; TR.hit++ }
    const pct = TR.pts.length ? TR.hit / TR.pts.length : 0; document.getElementById('meter').style.width = Math.round(Math.min(1, pct / .8) * 100) + '%';
    if (pct >= .8 && !TR.done && TR.out <= TR.inn * .6) { TR.done = true; const c = kid(); c.traced[ch] = (c.traced[ch] || 0) + 1; addStar(); logDay(); burst('✍️⭐✨'); document.getElementById('tmsg').textContent = 'Super tracing! ⭐'; play('p_super', gid(ch)) }
  };
  const ink = getComputedStyle(document.documentElement).getPropertyValue('--k2').trim() || '#2563EB';
  cv.onpointerdown = e => { cv.setPointerCapture(e.pointerId); TR.last = pos(e); mark(...TR.last) };
  cv.onpointermove = e => { if (!TR.last) return; const p = pos(e); g.lineCap = 'round'; g.lineJoin = 'round'; g.lineWidth = S * .085; g.strokeStyle = ink; g.beginPath(); g.moveTo(...TR.last); g.lineTo(...p); g.stroke(); TR.last = p; mark(...p) };
  cv.onpointerup = cv.onpointercancel = () => { TR.last = null };
}
AFTER.trace = () => { if (!open(traceList()[ti])) ti = 0; setupTrace().then(() => play('p_trace', gid(traceList()[ti]))) };
ACT.tstep = el => { const ls = traceList(); const n = (ti + +el.dataset.d + ls.length) % ls.length; if (!open(ls[n])) return locked(); ti = n; setupTrace(); play(gid(ls[ti])) };
ACT.tclear = () => setupTrace();
ACT.tsound = () => sayGrapheme(traceList()[ti]);

/* ---------- tricky words ---------- */
let tki = 0, TK = { mode: 'card', cur: null, tries: 0, done: false };
VIEWS.tricky = () => `${kidTop('Tricky words')}<div class="tabs center-tabs"><button aria-selected="${TK.mode === 'card'}" data-act="tkMode" data-m="card">👀 Look &amp; hear</button><button aria-selected="${TK.mode === 'find'}" data-act="tkMode" data-m="find">🎯 Find the word</button></div><div id="tk"></div>`;
ACT.tkMode = el => { TK.mode = el.dataset.m; render() };
function drawTricky() {
  const box = document.getElementById('tk'), c = kid(), T = DATA.tricky;
  if (TK.mode === 'card') {
    tki = (tki + T.length) % T.length; const w = T[tki];
    box.innerHTML = `<div class="big tword" data-act="tkHear" style="--cc:${col(w)}"><div class="glyph tw"><span class="L">${esc(w)}</span></div></div>
    <div class="row ctrl"><button class="btn sec arrow" data-act="tkStep" data-d="-1" aria-label="Previous">◀</button><button class="btn" data-act="tkHear">🔊 Hear it</button><button class="btn sec arrow" data-act="tkStep" data-d="1" aria-label="Next">▶</button></div>
    <div class="wordstrip">${T.map((x, i) => `<button class="${i === tki ? 'cur' : ''} ${openTricky(i) ? '' : 'lock'}" data-act="tkPick" data-i="${i}">${openTricky(i) ? '' : '🔒 '}${esc(x)}${c.tricky[x] >= 2 ? ' ✓' : ''}</button>`).join('')}</div>`;
  } else {
    const pool = T.filter((_, i) => openTricky(i));
    let t, g = 0; do { t = pool[Math.floor(Math.random() * pool.length)] } while (t === TK.cur && ++g < 20);
    TK.cur = t; TK.tries = 0; TK.done = false;
    const opts = [t]; g = 0; while (opts.length < 3 && g++ < 100) { const x = pool[Math.floor(Math.random() * pool.length)]; if (!opts.includes(x)) opts.push(x) }
    opts.sort(() => Math.random() - .5);
    box.innerHTML = `<div class="q"><h2>Can you find this word?</h2><button class="ear" data-act="tkReplay" aria-label="Hear the word again">👂</button>
      <div class="wchoices" id="wch">${opts.map(x => `<button data-w="${esc(x)}">${esc(x)}</button>`).join('')}</div><div class="msg" id="tmsg2"></div>
      <button class="btn hide" style="--cc:var(--k3)" id="tkNext" data-act="tkNext">Next ▶</button></div>`;
    document.getElementById('wch').onclick = e => {
      const b = e.target.closest('button'); if (!b || TK.done || b.classList.contains('no')) return;
      if (b.dataset.w === TK.cur) { TK.done = true; b.classList.add('ok'); if (TK.tries === 0) { c.tricky[TK.cur] = (c.tricky[TK.cur] || 0) + 1; addStar() } logDay(); document.getElementById('tmsg2').textContent = TK.tries ? 'You got it! 🎉' : 'Yes! ⭐'; document.getElementById('tkNext').classList.remove('hide'); play(['p_yes1', 'p_yes2', 'p_yes3'][Math.floor(Math.random() * 3)], wid(TK.cur)) }
      else { TK.tries++; b.classList.add('no'); document.getElementById('tmsg2').textContent = 'Nearly! Listen again 👂'; ask('p_try', wid(TK.cur), 'wch') }
    };
    bindActs(box); ask('p_findword', wid(t), 'wch'); return;
  }
  bindActs(box);
}
AFTER.tricky = () => { drawTricky(); if (TK.mode === 'card') play('p_tricky', wid(DATA.tricky[tki])) };
ACT.tkHear = () => { play(wid(DATA.tricky[tki])); logDay() };
ACT.tkStep = el => { const n = (tki + +el.dataset.d + DATA.tricky.length) % DATA.tricky.length; if (!openTricky(n)) return locked(); tki = n; drawTricky(); play(wid(DATA.tricky[tki])) };
ACT.tkPick = el => { const n = +el.dataset.i; if (!openTricky(n)) return locked(); tki = n; drawTricky(); play(wid(DATA.tricky[tki])) };
ACT.tkReplay = () => TK.cur && earSay(wid(TK.cur));
ACT.tkNext = () => drawTricky();

/* ---------- stickers ---------- */
VIEWS.stickers = () => { const c = kid(); const next = (c.stickers + 1) * 5 - c.stars; return `${kidTop('Stickers')}<h1 class="center" style="font-size:34px">${esc(c.name)}'s sticker book</h1>
  <p class="center muted">${c.stickers < DATA.stickers.length ? `${next} more ⭐ for the next sticker!` : 'You collected them all! 🏆'}</p>
  <div class="book">${DATA.stickers.map((s, i) => `<div class="${i < c.stickers ? 'got' : ''}">${i < c.stickers ? s : (i + 1) * 5 + '⭐'}</div>`).join('')}</div>` };

/* ---------- parent gate ---------- */
ACT.gate = el => {
  const to = el.dataset.to || 'parent'; const a = 5 + Math.floor(Math.random() * 7), b = 3 + Math.floor(Math.random() * 6), ans = a + b;
  const opts = [ans, ans + 2, ans - 3].sort(() => Math.random() - .5);
  overlay(`<div class="sheet"><h2>Grown-ups only</h2><p class="muted">Tap the answer to continue</p><p class="baloo" style="font-size:40px;margin:6px 0">${a} + ${b} = ?</p>
  <div class="nums">${opts.map(n => `<button data-act="gateAns" data-n="${n}" data-ok="${n === ans ? 1 : 0}" data-to="${to}">${n}</button>`).join('')}</div>
  <div class="row"><button class="btn sec sm" data-act="closeOv">Cancel</button></div></div>`);
};
ACT.gateAns = el => { closeOv(); if (el.dataset.ok === '1') go('parent', { tab: el.dataset.to === 'plan' ? 'plan' : 'progress' }); else toast('Not quite — ask a grown-up 🙂') };

/* ---------- parent zone ---------- */
const TABS = [['progress', 'Progress'], ['guide', 'Sound guide'], ['children', 'Children'], ['plan', 'Plan'], ['voice', 'Voice'], ['settings', 'Settings'], ['tips', 'Tips']];
VIEWS.parent = () => {
  const tab = vstate.tab || 'progress';
  return `<div class="top">${brandHtml()}<button class="btn sec sm" data-act="go" data-v="home">← Back to child</button></div>
  <div class="pz"><h1>Parent zone</h1>
  <div class="tabs" role="tablist">${TABS.map(([k, t]) => `<button role="tab" aria-selected="${k === tab}" data-act="ptab" data-t="${k}">${k === 'plan' ? (pro() ? 'Your plan' : '⭐ Unlock all') : t}</button>`).join('')}</div>
  <div id="ptab">${(PT[tab] || PT.progress)()}</div>${footerHtml()}</div>`;
};
ACT.ptab = el => { vstate.tab = el.dataset.t; render() };
const PT = {};
function level(c, x) { const r = c.right[x] || 0, w = c.wrong[x] || 0, t = c.traced[x] || 0; if ((r >= 3 && r / (r + w) >= .75) || (r >= 2 && t >= 1 && r / (r + w) >= .75)) return 'm'; if (r + w + t > 0 || c.seen[x]) return 'l'; return '' }
PT.progress = () => {
  const c = kid(); if (!c) return '<p>Add a child first.</p>';
  const m = ORDER.filter(x => level(c, x) === 'm').length, tk = DATA.tricky.filter(w => (c.tricky[w] || 0) >= 2).length;
  const days = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - 6 + i); return [d.toLocaleDateString('en-IN', { weekday: 'short' }), c.days[today(d)] || 0] });
  const mx = Math.max(5, ...days.map(d => d[1])), active = days.filter(d => d[1]).length;
  const tricky = ORDER.filter(x => (c.wrong[x] || 0) > (c.right[x] || 0)).slice(0, 6);
  const nextS = ORDER.find(x => open(x) && level(c, x) !== 'm');
  const sw = D.children.length > 1 ? `<div class="tabs">${D.children.map(k => `<button aria-selected="${k.id === c.id}" data-act="pkid" data-id="${k.id}">${k.avatar} ${esc(k.name)}</button>`).join('')}</div>` : '';
  return `${sw}<div class="kpis"><div class="kpi"><b>${m}/${ORDER.length}</b><span>sounds mastered</span></div><div class="kpi"><b>${tk}/${DATA.tricky.length}</b><span>tricky words known</span></div><div class="kpi"><b>${active}/7</b><span>days played this week</span></div></div>
  ${todayPlan(c)}
  <h2>${esc(c.name)} — sound by sound</h2>
  ${[1, 2, 3, 4].map(l => `<h3 class="lvh">Level ${l} · ${DATA.levels[l]}</h3><div class="prog">${ORDER.filter(x => LV(x) === l).map(x => `<div class="${level(c, x)} ${sz(x)}"><span class="L">${esc(caseOf(SD[x].gr))}</span><small>${c.right[x] || 0}✓ ${c.wrong[x] || 0}✗${c.traced[x] ? ' ✍️' : ''}</small></div>`).join('')}</div>`).join('')}
  <div class="key"><span><i style="background:var(--green)"></i>Mastered</span><span><i style="background:var(--amber)"></i>Learning</span><span><i style="border:2px solid var(--line)"></i>Not started</span><span>✓ right first time · ✗ needed another try · ✍️ traced</span></div>
  <h2>This week</h2><div class="card"><div class="week">${days.map(([d, n]) => `<div><i style="height:${Math.round(n / mx * 100)}%"></i>${d}</div>`).join('')}</div><p class="small muted" style="margin:8px 0 0">Activities completed each day. 5–10 minutes a day is plenty.</p></div>
  <h2>What to do next</h2><div class="card"><ul class="ticks" style="margin:0">
  ${nextS ? `<li>Practise <b>${esc(SD[nextS].gr)}</b> as in <b>${esc(SD[nextS].word)}</b> (level ${LV(nextS)}) — hear it in Sounds, then play Listen.</li>` : '<li>Every open sound is mastered. Wonderful!</li>'}
  ${tricky.length ? `<li>Tricky sounds: <b>${tricky.map(x => esc(SD[x].gr)).join(', ')}</b>. The Listen game already shows these more often.</li>` : '<li>No tricky sounds yet — keep playing Listen.</li>'}
  ${c.level < 4 && ORDER.filter(x => LV(x) === c.level).every(x => level(c, x) === 'm') ? `<li>Level ${c.level} is mastered — move ${esc(c.name)} to level ${c.level + 1} with the level buttons.</li>` : ''}
  ${!pro() ? `<li>${esc(c.name)} is using the free set. <button class="linkish" data-act="ptab" data-t="plan">Unlock all 44 sounds</button></li>` : ''}
  </ul></div>`;
};
ACT.pkid = el => { D.active = el.dataset.id; save(); render() };
function todayPlan(c) {
  const newS = ORDER.find(x => open(x) && !c.seen[x]) || ORDER.find(x => open(x) && level(c, x) !== 'm');
  const review = ORDER.filter(x => open(x) && x !== newS && c.seen[x] && level(c, x) !== 'm').sort((a, b) => (c.wrong[b] || 0) - (c.wrong[a] || 0)).slice(0, 2);
  const word = DATA.words.find(w => openWord(w) && !c.blended[w.word] && newS && w.tiles.some(t => t.snd === newS)) || DATA.words.find(w => openWord(w) && !c.blended[w.word]);
  const tw = DATA.tricky.find((w, i) => openTricky(i) && (c.tricky[w] || 0) < 2);
  const hear = (id, label) => `<button class="mini" data-act="rplay" data-id="${id}" aria-label="Hear ${esc(label)}">▶ ${esc(label)}</button>`;
  const steps = [];
  if (review.length) steps.push(`<li><b>Warm up (2 min):</b> say these sounds together: ${review.map(x => hear(gid(x), SD[x].gr)).join(' ')}</li>`);
  if (newS) { const t = DATA.tips[SD[newS].grp] || []; steps.push(`<li><b>New sound (3 min):</b> ${hear(gid(newS), SD[newS].gr)} as in ${hear(wid(SD[newS].word), SD[newS].word)}. ${esc(t[0] || '')} Say it, your child copies three times, then hunt for things at home that start with it.</li>`) }
  if (word) steps.push(`<li><b>Blend (3 min):</b> point to each letter of <b>${esc(word.word)}</b> and say the sounds — ${word.tiles.filter(x => x.snd).map(x => esc(x.show)).join('-')} — then push them together: ${hear(wid(word.word), word.word)}. Then play Blend in the app.</li>`);
  if (tw) steps.push(`<li><b>Tricky word (2 min):</b> ${hear(wid(tw), tw)}. Write it big, read it together and spot it in a book.</li>`);
  return `<h2>Today's 10-minute plan</h2><div class="card"><ol class="plan">${steps.join('')}</ol><p class="small muted" style="margin:6px 0 0">Do this sitting together, then let ${esc(c.name)} play on their own. New to phonics? Open the Sound guide tab first.</p></div>`;
}
PT.guide = () => {
  const seen = new Set(), groups = [];
  for (const id of ORDER) { const g = SD[id].grp; if (seen.has(g)) continue; seen.add(g); groups.push({ g, ids: ORDER.filter(x => SD[x].grp === g), level: LV(id) }) }
  const card = gr => { const main = gr.ids[0], t = DATA.tips[gr.g] || ['', ''];
    return `<div class="gcard"><div class="gg">${gr.ids.map(x => `<span class="L">${esc(caseOf(SD[x].gr))}</span>`).join('<i>·</i>')}</div>
    <div class="gb"><div class="gbtns"><button class="mini" data-act="rplay" data-id="${gid(main)}">▶ Sound</button>${gr.ids.map(x => `<button class="mini" data-act="rplay" data-id="${wid(SD[x].word)}">▶ ${esc(SD[x].word)}</button>`).join('')}</div>
    <p><b>Say it:</b> ${esc(t[0])}</p><p class="small"><b>Avoid:</b> ${esc(t[1])}</p>${open(main) ? '' : '<p class="small muted">🔒 Unlocks for your child with the full course — you can still listen here.</p>'}</div></div>` };
  return `<div class="card"><h2 style="margin-top:0">New to phonics? Start here</h2><ul class="ticks" style="margin:0">
    <li><b>Sounds first, names later.</b> Letters have names (ay, bee, see) and sounds (a, b, k). Reading starts with the sounds.</li>
    <li><b>Keep sounds pure and short:</b> "mmm", not "muh"; "t", not "tuh". The extra "uh" makes blending hard.</li>
    <li><b>Some sounds use two or three letters</b> — sh, ee, igh. They still make one sound.</li>
    <li><b>Blending</b> = say each sound, then push them together: c-a-t → cat. <b>Segmenting</b> is the reverse, for spelling: cat → c-a-t.</li>
    <li><b>Tricky words</b> (the, said, was) can't be sounded out, so learn them by sight.</li></ul></div>
  <h2>Teach any sound in 3 steps</h2><div class="card"><ol class="plan" style="margin:0"><li><b>Say it</b> — you say it, your child copies three times while looking at the letter.</li><li><b>Hunt it</b> — find three things at home that start with it ("sss… sofa, spoon, socks").</li><li><b>Write it</b> — trace it in the app, then in the air, in sand or on paper.</li></ol></div>
  ${[1, 2, 3, 4].map(l => `<h2>Level ${l} · ${DATA.levels[l]}</h2><div class="glist">${groups.filter(g => g.level === l).map(card).join('')}</div>`).join('')}
  <p class="small muted">Spellings shown together make the same sound. Tap ▶ to hear them in the app voice (or yours, if you recorded it).</p>`;
};
PT.children = () => `<div class="list">${D.children.map(c => `<div class="li"><span class="ic">${c.avatar}</span><div class="grow"><b>${esc(c.name)}</b><div class="small muted">Age ${c.age} · level ${c.level} · ⭐ ${c.stars} · ${c.stickers} stickers</div></div>
  <button class="btn sec sm" data-act="delKid" data-id="${c.id}">Remove</button></div>`).join('')}</div>
  <div class="row" style="justify-content:flex-start">${D.children.length < MAXK ? `<button class="btn" data-act="addKid">+ Add a child</button>` : `<span class="muted">Up to ${MAXK} children per family.</span>`}</div>`;
ACT.addKid = () => go('addKid');
ACT.delKid = el => { const c = D.children.find(k => k.id === el.dataset.id); overlay(`<div class="sheet"><h2>Remove ${esc(c.name)}?</h2><p class="muted">Their stars and progress on this device will be deleted.</p><div class="row"><button class="btn" style="--cc:var(--red)" data-act="delKidYes" data-id="${c.id}">Remove</button><button class="btn sec" data-act="closeOv">Cancel</button></div></div>`) };
ACT.delKidYes = el => { D.children = D.children.filter(k => k.id !== el.dataset.id); if (D.active === el.dataset.id) D.active = D.children[0]?.id || null; save(); closeOv(); if (!D.children.length) go('addKid'); else render() };

PT.settings = () => `<div class="set">
  <label>Letter style<select id="sCase"><option value="lower">lowercase (a)</option><option value="upper">CAPITALS (A)</option><option value="both">Both (Aa)</option></select></label>
  <label>Voice<select id="sVoice"><option value="1">Your recorded voice when available</option><option value="0">Always the app voice</option></select></label>
  <label>Backup voice speed: <span id="rv">${D.settings.rate}</span><input id="sRate" type="range" min="0.5" max="1.1" step="0.05" value="${D.settings.rate}"></label>
  <label>Test the sound<button class="btn sm" type="button" data-act="testSound">🔊 Play "s… sun"</button></label>
  </div><p class="small muted">Lowercase is how children first learn to read; schools introduce capitals later. Progress is saved on this device and browser.</p>`;
AFTER.parent = () => {
  const sc = document.getElementById('sCase'); if (sc) { sc.value = D.settings.caseMode; sc.onchange = () => { D.settings.caseMode = sc.value; save() } }
  const sv = document.getElementById('sVoice'); if (sv) { sv.value = D.settings.myVoice ? '1' : '0'; sv.onchange = () => { D.settings.myVoice = sv.value === '1'; save() } }
  const sr = document.getElementById('sRate'); if (sr) { sr.oninput = () => { D.settings.rate = +sr.value; document.getElementById('rv').textContent = sr.value; save() } }
};
ACT.testSound = () => play('g_s', 'w_sun');

/* plan & payment */
PT.plan = () => {
  if (pro()) return `<div class="ok-note"><b>✓ Everything is unlocked.</b> ${LIC && LIC.email ? 'Purchased with ' + esc(LIC.email) + '.' : demoPro ? '(Preview demo unlock.)' : ''}</div>
    <p>All 44 sounds (69 spellings), ${DATA.words.length} blending words, ${DATA.tricky.length} tricky words, tracing for every letter and up to ${MAXK} children.</p>${LIC && LIC.expires ? `<p><b>Access until ${fmtDate(LIC.expires)}.</b></p>` : ''}
    <p class="small muted">To use it on another phone or tablet, open this website there, go to Parent zone → Your plan → “Already paid?” and enter the same email and the payment ID from your receipt${LIC && LIC.pid ? ` (<b>${esc(LIC.pid)}</b>)` : ''}.</p>`;
  return `<div class="price"><div><div class="amt">${esc(CFG.priceLabel)}</div><div>${esc(CFG.priceNote)}</div></div></div>
  <ul class="ticks"><li>The complete course: all 44 sounds, 69 spellings, 4 levels (free: s a t p i n)</li><li>Listening game and finger tracing for every letter</li><li>All ${DATA.words.length} blending words (free: ${DATA.words.filter(w => w.tiles.every(t => !t.snd || FREE.includes(t.snd))).length})</li><li>All ${DATA.tricky.length} tricky words (free: ${DATA.freeTricky})</li><li>Record the sounds in your own voice</li><li>Up to ${MAXK} children, a progress report for each</li><li>A parent sound guide, so you can learn every sound too</li><li>Pay once for ${CFG.accessYears || 3} years — no subscription, no auto-renewal, no ads</li></ul>
  <form class="card" data-act="buy">
   <h3 class="baloo" style="font-size:22px">Unlock with UPI, card or netbanking</h3>
   <label class="field">Your email (for the receipt)<input id="bEmail" type="email" required autocomplete="email" value="${esc(store.get('pp_email', ''))}"></label>
   <label class="field">Mobile number<input id="bPhone" type="tel" inputmode="tel" required pattern="[0-9+ ]{10,14}" autocomplete="tel"></label>
   <button class="btn block" type="submit" id="payBtn">Pay ${esc(CFG.priceLabel)} securely</button>
   <p class="small muted center" style="margin:10px 0 0">Payments are processed by Razorpay. We never see your card or UPI details.</p>
   <div id="payMsg"></div>
  </form>
  <h2>Already paid?</h2>
  <form class="card" data-act="restore">
   <label class="field">Email used to pay<input id="rEmail" type="email" required></label>
   <label class="field">Payment ID from your receipt (starts with pay_)<input id="rPid" required pattern="pay_[A-Za-z0-9]+"></label>
   <button class="btn sec block" type="submit">Restore my purchase</button><div id="rMsg"></div>
  </form>`;
};
function loadRzp() { return new Promise((res, rej) => { if (window.Razorpay) return res(); const s = document.createElement('script'); s.src = 'https://checkout.razorpay.com/v1/checkout.js'; s.onload = res; s.onerror = () => rej(new Error('Could not load the payment window. Check your internet.')); document.head.appendChild(s) }) }
function setMsg(id, html, ok) { const m = document.getElementById(id); if (m) m.innerHTML = `<div class="${ok ? 'ok-note' : 'note'}" style="margin-top:12px">${html}</div>` }
ACT.buy = async () => {
  const email = document.getElementById('bEmail').value.trim(), phone = document.getElementById('bPhone').value.trim();
  store.set('pp_email', email);
  if (!API_OK && !CFG.preview) { setMsg('payMsg', 'We could not reach the payment service. Check your internet and try again in a minute.'); return }
  if (!API_OK) { setMsg('payMsg', `This is a preview copy, so payments are switched off here. On the live website the Razorpay window opens at this step.<br><button class="btn sm" style="margin-top:8px" data-act="demoUnlock">Preview: unlock everything</button>`); bindActs(document.getElementById('payMsg')); return }
  const btn = document.getElementById('payBtn'); btn.disabled = true; btn.textContent = 'Opening secure payment…';
  const reset = () => { btn.disabled = false; btn.textContent = 'Pay ' + CFG.priceLabel + ' securely' };
  try {
    await loadRzp();
    const o = await api('order', { email, phone });
    const rz = new Razorpay({
      key: o.key, amount: o.amount, currency: o.currency, order_id: o.order_id, name: CFG.appName, description: o.description,
      prefill: { email, contact: phone }, notes: { product: 'pragati-phonics' }, theme: { color: '#E85D04' },
      handler: async r => {
        try {
          const v = await api('verify', { ...r, email });
          LIC = { token: v.token, email, pid: r.razorpay_payment_id, expires: v.expires }; store.set('pp_license', LIC);
          burst('🎉⭐🔓'); vstate.tab = 'plan'; render(); toast('Thank you! Everything is unlocked.');
        } catch (e) { setMsg('payMsg', 'Payment received but we could not confirm it automatically. Please use “Already paid?” below with payment ID <b>' + esc(r.razorpay_payment_id) + '</b>, or contact us.') }
      },
      modal: { ondismiss: reset }
    });
    rz.on('payment.failed', r => setMsg('payMsg', 'Payment did not go through: ' + esc(r.error && r.error.description || 'please try again') + '. No money was taken for a failed payment.'));
    rz.open();
  } catch (e) { setMsg('payMsg', esc(e.message)); reset() }
};
ACT.demoUnlock = () => { demoPro = true; closeOv(); vstate.tab = 'plan'; render(); toast('Preview: everything unlocked until you reload.') };
ACT.restore = async () => {
  if (!API_OK) { setMsg('rMsg', 'Restoring works on the live website.'); return }
  try { const j = await api('restore', { email: document.getElementById('rEmail').value.trim(), payment_id: document.getElementById('rPid').value.trim() }); LIC = { token: j.token, email: j.email, pid: j.payment_id, expires: j.expires }; store.set('pp_license', LIC); burst('🎉🔓'); render(); toast('Purchase restored.') }
  catch (e) { setMsg('rMsg', esc(e.message)) }
};

/* voice recorder */
function CLIPS() {
  const seen = new Set(), uniq = arr => arr.filter(([id]) => !seen.has(id) && seen.add(id));
  return [
    ['Sounds', uniq(ORDER.map(x => [gid(x), SD[x].gr, 'pure sound, like “' + SD[x].say + '” in ' + SD[x].word]))],
    ['Picture words', uniq(ORDER.map(x => [wid(SD[x].word), SD[x].word, '']))],
    ['Blending words', uniq(DATA.words.map(w => [wid(w.word), w.word, '']))],
    ['Tricky words', uniq(DATA.tricky.map(w => [wid(w), w, '']))],
    ['Praise & instructions', uniq(Object.entries(DATA.phrases).map(([k, t]) => [k, t, '']))]
  ];
}
let REC = null;
PT.voice = () => {
  const canRec = !!(navigator.mediaDevices && window.MediaRecorder);
  const n = Object.keys(AUD.mine).length;
  return `<p>Children learn sounds best from a familiar voice. Record any clip below — your recording replaces the app voice on this device. ${n ? `<span class="mine">${n} recorded</span>` : ''}</p>
  ${canRec ? '' : '<div class="note">Recording is not available in this browser or preview. Open the website in Chrome or Safari on your phone.</div>'}
  <p class="small muted">Tips: a quiet room, phone 20 cm from your mouth. Say pure sounds — “mmm” not “muh”, “sss” not “suh”. Tap ● to start, ■ to stop (stops by itself after 4 seconds).</p>
  ${CLIPS().map(([h, items]) => `<details class="recgrp"><summary><b>${h}</b> <span class="muted small">${items.length} clips · ${items.filter(([id]) => AUD.mine[id]).length} yours</span></summary><div class="list">${items.map(([id, label, hint]) => `<div class="recrow"><div class="t"><b>${esc(label)}</b> ${AUD.mine[id] ? '<span class="mine small">● yours</span>' : ''}<br><small>${esc(hint)}</small></div>
   <div class="b"><button data-act="rplay" data-id="${id}" aria-label="Play">▶</button>${canRec ? `<button data-act="rrec" data-id="${id}" aria-label="Record">●</button>` : ''}${AUD.mine[id] ? `<button data-act="rdel" data-id="${id}" aria-label="Delete my recording">✕</button>` : ''}</div></div>`).join('')}</div></details>`).join('')}
  ${ADMIN ? `<h2>Studio (owner)</h2><div class="card"><p>Upload your recordings to the website so <b>every family</b> hears them.</p><button class="btn" data-act="uploadAll">Upload ${n} recordings</button><div id="upMsg"></div></div>` : ''}`;
};
ACT.rplay = el => play(el.dataset.id);
ACT.rdel = async el => { const id = el.dataset.id; await idb.del(id); URL.revokeObjectURL(AUD.mine[id]); delete AUD.mine[id]; delete MINE_BLOBS[id]; keepOpen(render) };
function keepOpen(fn) { const openG = [...document.querySelectorAll('details.recgrp')].map(d => d.open); fn(); document.querySelectorAll('details.recgrp').forEach((d, i) => { d.open = !!openG[i] }) }
ACT.rrec = async el => {
  const id = el.dataset.id;
  if (REC) { REC.stop(); return }
  try {
    stopAudio();
    const st = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    const mr = new MediaRecorder(st); const chunks = []; REC = mr; el.classList.add('rec'); el.textContent = '■';
    mr.ondataavailable = e => e.data.size && chunks.push(e.data);
    mr.onstop = async () => {
      st.getTracks().forEach(t => t.stop()); REC = null;
      const blob = new Blob(chunks, { type: mr.mimeType || 'audio/webm' });
      if (blob.size < 800) { toast('That was too short — try again.'); keepOpen(render); return }
      await idb.put(id, blob); MINE_BLOBS[id] = blob; if (AUD.mine[id]) URL.revokeObjectURL(AUD.mine[id]); AUD.mine[id] = URL.createObjectURL(blob);
      keepOpen(render); play(id);
    };
    mr.start(); setTimeout(() => { if (mr.state === 'recording') mr.stop() }, 4000);
  } catch (e) { REC = null; toast('Microphone not allowed. Check the browser permission.') }
};
const ADMIN = (() => { try { return new URLSearchParams(location.search).has('studio') } catch (e) { return false } })();
ACT.uploadAll = async () => {
  let key = ''; try { key = sessionStorage.getItem('pp_admin') || '' } catch (e) {}
  if (!key) { overlay(`<div class="sheet"><h2>Studio key</h2><form data-act="setKey"><label class="field">Admin key from config.php<input id="ak" type="password" required></label><button class="btn block">Continue</button></form></div>`); return }
  const ids = Object.keys(MINE_BLOBS); let ok = 0;
  for (const id of ids) {
    const b = MINE_BLOBS[id]; const data = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(String(fr.result).split(',')[1]); fr.readAsDataURL(b) });
    try { await api('audio', { key, id, type: b.type, data }); ok++; setMsg('upMsg', `Uploaded ${ok} of ${ids.length}…`, true) } catch (e) { setMsg('upMsg', esc(e.message)); if (/key/i.test(e.message)) { try { sessionStorage.removeItem('pp_admin') } catch (x) {} } return }
  }
  setMsg('upMsg', `Done — ${ok} recordings are now live for every family.`, true); loadManifest();
};
ACT.setKey = () => { try { sessionStorage.setItem('pp_admin', document.getElementById('ak').value) } catch (e) {} closeOv(); ACT.uploadAll() };

PT.tips = () => `<div class="card"><ul class="ticks" style="margin:0">
  <li><b>Say pure sounds.</b> “mmm”, “sss”, “fff” — not “muh”, “suh”. Clipped sounds make blending much easier later.</li>
  <li><b>Little and often.</b> 5–10 minutes a day beats one long session. Stop while it is still fun.</li>
  <li><b>Follow the levels.</b> Level 1 (s a t p i n…) → level 2 (j v w x…) → level 3 (sh ch ee igh…) → level 4 (other spellings like ay, ea, magic e). Move on when the parent report shows most sounds green.</li>
  <li><b>Blend out loud together</b> — “sh… i… p… ship!” — and point to each tile as you say it.</li>
  <li><b>Tricky words</b> can't be sounded out, so practise them a few at a time, like sight words.</li>
  <li><b>Trace in the air and on paper too</b> after tracing on screen.</li>
  <li><b>Ages 3–4:</b> hearing and saying sounds (level 1). <b>Ages 5–6:</b> tracing, blending, level 2–3. <b>6–7:</b> level 4 and tricky words.</li>
  <li><b>Praise effort,</b> not only right answers. The app never shows a “wrong” buzzer, and neither should we.</li></ul></div>`;

/* ---------- start ---------- */
(async () => {
  render();
  fitLetters();
  await Promise.all([loadManifest(), loadMine(), ping()]);
  await checkLicense();
  if (view === 'parent') render();
})();
}
