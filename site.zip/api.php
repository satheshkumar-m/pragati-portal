<?php
/* Pragati Phonics — server API (PHP 7.4+, works on Hostinger shared hosting).
   Actions (POST JSON, ?a=...): ping, order, verify, check, restore, audio (owner), webhook (Razorpay). */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

$cfgFile = __DIR__ . '/config.php';
if (!is_file($cfgFile)) { out(['error' => 'Server not configured (config.php missing).'], 500); }
require $cfgFile;

const DATA_DIR = __DIR__ . '/data';
const AUDIO_DIR = __DIR__ . '/audio';

function out(array $j, int $code = 200): void { http_response_code($code); echo json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function fail(string $m, int $code = 400): void { out(['error' => $m], $code); }
function b64u(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function b64ud(string $s): string { return (string)base64_decode(strtr($s, '-_', '+/')); }
function keysReady(): bool { return RZP_KEY_ID !== '' && RZP_KEY_SECRET !== '' && strpos(RZP_KEY_ID, 'rzp_') === 0; }

function withJson(string $file, callable $fn) {
  if (!is_dir(DATA_DIR)) { @mkdir(DATA_DIR, 0750, true); }
  $fh = fopen($file, 'c+'); if (!$fh) { fail('Storage error', 500); }
  flock($fh, LOCK_EX);
  $raw = stream_get_contents($fh); $data = $raw ? (json_decode($raw, true) ?: []) : [];
  $res = $fn($data);
  ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  fflush($fh); flock($fh, LOCK_UN); fclose($fh);
  return $res;
}
function readJson(string $file): array { if (!is_file($file)) return []; return json_decode((string)file_get_contents($file), true) ?: []; }

function token(string $email, string $pid): string {
  $p = b64u(json_encode(['e' => $email, 'p' => $pid, 't' => time()]));
  return $p . '.' . b64u(hash_hmac('sha256', $p, APP_SECRET, true));
}
function readToken(string $t): ?array {
  $parts = explode('.', $t); if (count($parts) !== 2) return null;
  $sig = b64u(hash_hmac('sha256', $parts[0], APP_SECRET, true));
  if (!hash_equals($sig, $parts[1])) return null;
  $j = json_decode(b64ud($parts[0]), true); return is_array($j) ? $j : null;
}
function rzp(string $method, string $path, ?array $body = null): array {
  $ch = curl_init('https://api.razorpay.com/v1' . $path);
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_USERPWD => RZP_KEY_ID . ':' . RZP_KEY_SECRET, CURLOPT_TIMEOUT => 20,
    CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => ['Content-Type: application/json']]);
  if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
  $res = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  $j = json_decode((string)$res, true) ?: [];
  if ($code < 200 || $code >= 300) fail('Payment service error: ' . ($j['error']['description'] ?? 'please try again'), 502);
  return $j;
}
function record(string $email, string $phone, string $pid, string $oid, int $amount, string $via): void {
  withJson(DATA_DIR . '/purchases.json', function (&$d) use ($email, $phone, $pid, $oid, $amount, $via) {
    if (!isset($d[$pid])) $d[$pid] = ['email' => $email, 'phone' => $phone, 'order_id' => $oid, 'amount' => $amount, 'via' => $via, 'at' => date('c')];
    elseif ($email && !$d[$pid]['email']) $d[$pid]['email'] = $email;
  });
}
function accessDays(): int { return defined('ACCESS_DAYS') ? (int)ACCESS_DAYS : 1095; }
function expiresMs(array $row): int { return (strtotime($row['at']) + accessDays() * 86400) * 1000; }
function cleanEmail($e): string { $e = strtolower(trim((string)$e)); return filter_var($e, FILTER_VALIDATE_EMAIL) ? $e : ''; }

$a = $_GET['a'] ?? '';
$raw = (string)file_get_contents('php://input');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('POST only', 405);
$in = json_decode($raw, true) ?: [];

switch ($a) {
  case 'ping':
    out(['ok' => true, 'payments' => keysReady(), 'price_label' => PRICE_LABEL, 'access_days' => accessDays()]);

  case 'order': {
    if (!keysReady()) fail('Payments are not switched on yet. Please try again soon.', 503);
    $email = cleanEmail($in['email'] ?? ''); $phone = preg_replace('/[^0-9+]/', '', (string)($in['phone'] ?? ''));
    if (!$email) fail('Please enter a valid email.');
    if (strlen($phone) < 10) fail('Please enter a valid mobile number.');
    $o = rzp('POST', '/orders', ['amount' => PRICE_PAISE, 'currency' => 'INR', 'receipt' => 'pp_' . bin2hex(random_bytes(6)),
      'notes' => ['product' => 'pragati-phonics', 'email' => $email, 'phone' => $phone]]);
    withJson(DATA_DIR . '/orders.json', function (&$d) use ($o, $email, $phone) { $d[$o['id']] = ['email' => $email, 'phone' => $phone, 'at' => date('c')]; });
    out(['key' => RZP_KEY_ID, 'order_id' => $o['id'], 'amount' => PRICE_PAISE, 'currency' => 'INR', 'description' => PRODUCT_DESC]);
  }

  case 'verify': {
    if (!keysReady()) fail('Payments are not switched on yet.', 503);
    $oid = (string)($in['razorpay_order_id'] ?? ''); $pid = (string)($in['razorpay_payment_id'] ?? ''); $sig = (string)($in['razorpay_signature'] ?? '');
    if (!preg_match('/^order_\w+$/', $oid) || !preg_match('/^pay_\w+$/', $pid)) fail('Invalid payment details.');
    $exp = hash_hmac('sha256', $oid . '|' . $pid, RZP_KEY_SECRET);
    if (!hash_equals($exp, $sig)) fail('Payment could not be verified.', 400);
    $orders = readJson(DATA_DIR . '/orders.json'); $o = $orders[$oid] ?? null;
    if (!$o) fail('Unknown order.', 400);
    record($o['email'], $o['phone'], $pid, $oid, PRICE_PAISE, 'checkout');
    $row = readJson(DATA_DIR . '/purchases.json')[$pid] ?? ['at' => date('c')];
    out(['ok' => true, 'token' => token($o['email'], $pid), 'expires' => expiresMs($row)]);
  }

  case 'check': {
    $t = readToken((string)($in['token'] ?? ''));
    if (!$t) out(['valid' => false]);
    $p = readJson(DATA_DIR . '/purchases.json');
    $row = $p[$t['p']] ?? null;
    if ($row === null || !empty($row['refunded'])) out(['valid' => false]);
    $exp = expiresMs($row);
    out(['valid' => $exp > time() * 1000, 'expires' => $exp]);
  }

  case 'restore': {
    $email = cleanEmail($in['email'] ?? ''); $pid = trim((string)($in['payment_id'] ?? ''));
    usleep(400000); // slow down guessing
    $p = readJson(DATA_DIR . '/purchases.json'); $row = $p[$pid] ?? null;
    if (!$row || !$email || strtolower($row['email']) !== $email) fail('We could not find a purchase with that email and payment ID. Check your Razorpay receipt email, or contact us.', 404);
    if (!empty($row['refunded'])) fail('This purchase was refunded.', 403);
    if (expiresMs($row) <= time() * 1000) fail('This purchase has ended (3 years from the payment date).', 403);
    out(['ok' => true, 'token' => token($email, $pid), 'email' => $email, 'payment_id' => $pid, 'expires' => expiresMs($row)]);
  }

  case 'audio': {
    if (ADMIN_KEY === '' || !hash_equals(ADMIN_KEY, (string)($in['key'] ?? ''))) fail('Wrong studio key.', 403);
    $id = (string)($in['id'] ?? '');
    if (!preg_match('/^[a-z][a-z0-9_]{1,39}$/', $id)) fail('Bad clip id.');
    $types = ['audio/webm' => 'webm', 'audio/ogg' => 'ogg', 'audio/mp4' => 'm4a', 'audio/aac' => 'aac', 'audio/mpeg' => 'mp3', 'audio/wav' => 'wav', 'audio/x-wav' => 'wav'];
    $type = strtolower(explode(';', (string)($in['type'] ?? ''))[0]);
    $ext = $types[$type] ?? null; if (!$ext) fail('Unsupported audio type.');
    $bin = base64_decode((string)($in['data'] ?? ''), true);
    if ($bin === false || strlen($bin) < 500 || strlen($bin) > 1500000) fail('Audio file too small or too large.');
    if (!is_dir(AUDIO_DIR)) @mkdir(AUDIO_DIR, 0755, true);
    foreach (glob(AUDIO_DIR . '/' . $id . '.*') ?: [] as $old) @unlink($old);
    file_put_contents(AUDIO_DIR . "/$id.$ext", $bin);
    $mf = AUDIO_DIR . '/manifest.json';
    $fh = fopen($mf, 'c+'); flock($fh, LOCK_EX); $m = json_decode((string)stream_get_contents($fh), true) ?: [];
    $m[$id] = "$id.$ext?v=" . time(); ksort($m);
    ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($m, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)); flock($fh, LOCK_UN); fclose($fh);
    out(['ok' => true]);
  }

  case 'webhook': {
    // Razorpay Dashboard → Webhooks → URL https://<site>/api.php?a=webhook, events: payment.captured, refund.processed
    $sig = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';
    if (RZP_WEBHOOK_SECRET === '' || !hash_equals(hash_hmac('sha256', $raw, RZP_WEBHOOK_SECRET), $sig)) fail('Bad signature', 400);
    $ev = $in['event'] ?? '';
    if ($ev === 'payment.captured') {
      $pay = $in['payload']['payment']['entity'] ?? [];
      $oid = (string)($pay['order_id'] ?? ''); $orders = readJson(DATA_DIR . '/orders.json'); $o = $orders[$oid] ?? [];
      if (($pay['notes']['product'] ?? '') === 'pragati-phonics' || $o)
        record(cleanEmail($o['email'] ?? ($pay['email'] ?? '')), (string)($o['phone'] ?? ($pay['contact'] ?? '')), (string)$pay['id'], $oid, (int)($pay['amount'] ?? 0), 'webhook');
    } elseif ($ev === 'refund.processed') {
      $pid = (string)($in['payload']['refund']['entity']['payment_id'] ?? '');
      if ($pid) withJson(DATA_DIR . '/purchases.json', function (&$d) use ($pid) { if (isset($d[$pid])) $d[$pid]['refunded'] = date('c'); });
    }
    out(['ok' => true]);
  }

  default:
    fail('Unknown action', 404);
}
