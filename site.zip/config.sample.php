<?php
/* Pragati Phonics — SECRET server settings.
   Copy this file to config.php on the server and fill it in. Never share config.php. */

// Razorpay → Dashboard → Account & Settings → API Keys. Use rzp_test_... keys first, then rzp_live_... after KYC.
const RZP_KEY_ID = '';
const RZP_KEY_SECRET = '';
// Razorpay → Webhooks → add https://phonics.avrajarooms.in/api.php?a=webhook (payment.captured, refund.processed)
const RZP_WEBHOOK_SECRET = '';

// Price in paise (99900 = ₹999). Keep PRICE_LABEL and config.js priceLabel the same.
const PRICE_PAISE = 99900;
const PRICE_LABEL = '₹999';
const PRODUCT_DESC = 'Pragati Phonics — 3 years family access (2 children)';
// How long a purchase unlocks the app.
const ACCESS_DAYS = 1095;

// Long random strings. APP_SECRET signs unlock tokens; ADMIN_KEY lets you upload voice recordings (?studio).
const APP_SECRET = 'CHANGE-ME';
const ADMIN_KEY = 'CHANGE-ME';
